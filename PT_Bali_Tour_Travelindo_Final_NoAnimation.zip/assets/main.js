(function(){
  // simple slide switch (no animation)
  // background image set in CSS inline for hero
  // includes detail content map
  const detailMap = {
    snorkel: '<h4>Include — Snorkeling</h4><ul><li>Alat snorkeling lengkap</li><li>Perahu ke spot</li><li>Guide & dokumentasi</li><li>Snack & air mineral</li></ul>',
    atv: '<h4>Include — ATV</h4><ul><li>Helm & rompi</li><li>Pemandu</li><li>Transport lokal</li><li>Foto aktivitas</li></ul>',
    rafting: '<h4>Include — Rafting</h4><ul><li>Peralatan keselamatan</li><li>Instruktur berpengalaman</li><li>Transport & snack</li></ul>'
  };
  window.openIncludes = function(key){
    const panel = document.getElementById('detail-panel');
    document.getElementById('detail-content').innerHTML = detailMap[key] || '';
    panel.classList.add('show');
    panel.setAttribute('aria-hidden','false');
  };
  window.closeDetails = function(){
    const panel = document.getElementById('detail-panel');
    panel.classList.remove('show');
    panel.setAttribute('aria-hidden','true');
  };

  // booking form -> WA message
  const WA = '6285142928714';
  const form = document.getElementById('bookingForm');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const name = encodeURIComponent(document.getElementById('name').value || '-');
      const email = encodeURIComponent(document.getElementById('email').value || '-');
      const phone = encodeURIComponent(document.getElementById('phone').value || '-');
      const pkg = encodeURIComponent(document.getElementById('package').value || '-');
      const date = encodeURIComponent(document.getElementById('date').value || '-');
      const people = encodeURIComponent(document.getElementById('people').value || '-');
      const note = encodeURIComponent(document.getElementById('note').value || '-');
      const msg = 'Halo PT Bali Tour Travelindo,%0A%0ASaya ingin memesan paket: '+pkg+
                  '%0A%0ANama: '+name+'%0AEmail: '+email+'%0ANo WA: '+phone+
                  '%0A%0ATanggal: '+date+'%0AJumlah peserta: '+people+
                  '%0A%0ACatatan: '+note;
      const url = 'https://wa.me/'+WA+'?text='+msg;
      window.open(url, '_blank');
    });
  }

  // language switch (simple text swap)
  const langSelect = document.getElementById('langSelect');
  const texts = {
    en: {
      brandTitle: 'PT Bali Tour Travelindo',
      tag: 'Snorkeling • ATV • Rafting',
      heroTitle: 'Discover Bali\'s underwater paradise with our professional snorkeling tours.',
      heroSub: 'Snorkeling • ATV • Rafting — Safe, family-friendly, and affordable tour experiences.',
      packagesTitle: 'Our Tour Packages',
      bookingTitle: 'Booking Form',
      contactTitle: 'Contact & Location'
    },
    id: {
      brandTitle: 'PT Bali Tour Travelindo',
      tag: 'Snorkeling • ATV • Rafting',
      heroTitle: 'Jelajahi surga bawah laut Bali dengan tur snorkeling profesional kami.',
      heroSub: 'Snorkeling • ATV • Rafting — Aman, ramah keluarga, dan terjangkau.',
      packagesTitle: 'Aktivitas Populer',
      bookingTitle: 'Form Pemesanan',
      contactTitle: 'Kontak & Lokasi'
    }
  };
  function applyLang(code){
    const t = texts[code] || texts['en'];
    document.getElementById('brand-title').textContent = t.brandTitle;
    document.getElementById('brand-tag').textContent = t.tag;
    document.getElementById('hero-title').textContent = t.heroTitle;
    document.getElementById('hero-sub').textContent = t.heroSub;
    document.getElementById('packages-title').textContent = t.packagesTitle;
    document.getElementById('booking-title').textContent = t.bookingTitle;
    document.getElementById('contact-title').textContent = t.contactTitle;
  }
  if(langSelect){
    langSelect.addEventListener('change', function(){ applyLang(this.value); });
  }
  // init default lang id
  applyLang('id');
})();